//
//  Playing_Video_FilesAppDelegate.h
//  Playing Video Files
//
//  Created by Vandad Nahavandipoor on 16/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Playing_Video_FilesViewController;

@interface Playing_Video_FilesAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Playing_Video_FilesViewController *viewController;

@end
