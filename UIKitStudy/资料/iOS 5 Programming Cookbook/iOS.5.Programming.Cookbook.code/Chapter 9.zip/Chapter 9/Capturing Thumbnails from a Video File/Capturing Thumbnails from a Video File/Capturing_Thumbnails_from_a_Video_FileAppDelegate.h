//
//  Capturing_Thumbnails_from_a_Video_FileAppDelegate.h
//  Capturing Thumbnails from a Video File
//
//  Created by Vandad Nahavandipoor on 16/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Capturing_Thumbnails_from_a_Video_FileViewController;

@interface Capturing_Thumbnails_from_a_Video_FileAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Capturing_Thumbnails_from_a_Video_FileViewController *viewController;

@end
