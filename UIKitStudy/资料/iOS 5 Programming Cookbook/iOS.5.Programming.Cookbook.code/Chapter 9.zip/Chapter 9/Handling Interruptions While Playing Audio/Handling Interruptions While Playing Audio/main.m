//
//  main.m
//  Handling Interruptions While Playing Audio
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Handling_Interruptions_While_Playing_AudioAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Handling_Interruptions_While_Playing_AudioAppDelegate class]));
  }
}
