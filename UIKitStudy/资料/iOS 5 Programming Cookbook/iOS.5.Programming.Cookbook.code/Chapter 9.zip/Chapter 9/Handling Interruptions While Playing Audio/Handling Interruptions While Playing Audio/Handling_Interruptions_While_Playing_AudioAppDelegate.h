//
//  Handling_Interruptions_While_Playing_AudioAppDelegate.h
//  Handling Interruptions While Playing Audio
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Handling_Interruptions_While_Playing_AudioViewController;

@interface Handling_Interruptions_While_Playing_AudioAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Handling_Interruptions_While_Playing_AudioViewController *viewController;

@end
