//
//  Handling_Interruptions_While_Recording_AudioAppDelegate.h
//  Handling Interruptions While Recording Audio
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Handling_Interruptions_While_Recording_AudioViewController;

@interface Handling_Interruptions_While_Recording_AudioAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Handling_Interruptions_While_Recording_AudioViewController *viewController;

@end
