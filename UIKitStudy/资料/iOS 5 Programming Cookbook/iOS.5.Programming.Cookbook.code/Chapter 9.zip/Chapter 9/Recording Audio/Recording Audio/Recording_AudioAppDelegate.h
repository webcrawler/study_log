//
//  Recording_AudioAppDelegate.h
//  Recording Audio
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Recording_AudioViewController;

@interface Recording_AudioAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Recording_AudioViewController *viewController;

@end
