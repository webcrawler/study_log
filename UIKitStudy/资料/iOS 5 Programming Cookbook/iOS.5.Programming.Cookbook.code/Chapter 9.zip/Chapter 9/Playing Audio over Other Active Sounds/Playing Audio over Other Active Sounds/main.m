//
//  main.m
//  Playing Audio over Other Active Sounds
//
//  Created by Vandad Nahavandipoor on 16/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Playing_Audio_over_Other_Active_SoundsAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Playing_Audio_over_Other_Active_SoundsAppDelegate class]));
  }
}
