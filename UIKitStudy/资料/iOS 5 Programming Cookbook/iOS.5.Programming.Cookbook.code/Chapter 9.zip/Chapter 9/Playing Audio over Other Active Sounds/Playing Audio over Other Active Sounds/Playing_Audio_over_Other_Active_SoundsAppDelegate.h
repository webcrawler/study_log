//
//  Playing_Audio_over_Other_Active_SoundsAppDelegate.h
//  Playing Audio over Other Active Sounds
//
//  Created by Vandad Nahavandipoor on 16/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Playing_Audio_over_Other_Active_SoundsViewController;

@interface Playing_Audio_over_Other_Active_SoundsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Playing_Audio_over_Other_Active_SoundsViewController *viewController;

@end
