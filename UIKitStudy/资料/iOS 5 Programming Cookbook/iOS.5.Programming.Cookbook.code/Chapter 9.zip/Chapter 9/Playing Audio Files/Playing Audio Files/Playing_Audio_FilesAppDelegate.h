//
//  Playing_Audio_FilesAppDelegate.h
//  Playing Audio Files
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Playing_Audio_FilesViewController;

@interface Playing_Audio_FilesAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Playing_Audio_FilesViewController *viewController;

@end
