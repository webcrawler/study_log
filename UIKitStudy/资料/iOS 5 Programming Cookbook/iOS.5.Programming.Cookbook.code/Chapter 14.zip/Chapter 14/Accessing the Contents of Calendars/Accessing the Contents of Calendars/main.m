//
//  main.m
//  Accessing the Contents of Calendars
//
//  Created by Vandad Nahavandipoor on 24/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Accessing_the_Contents_of_CalendarsAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Accessing_the_Contents_of_CalendarsAppDelegate class]));
  }
}
