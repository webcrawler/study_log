//
//  main.m
//  Handling Event Changed Notifications
//
//  Created by Vandad Nahavandipoor on 24/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Handling_Event_Changed_NotificationsAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Handling_Event_Changed_NotificationsAppDelegate class]));
  }
}
