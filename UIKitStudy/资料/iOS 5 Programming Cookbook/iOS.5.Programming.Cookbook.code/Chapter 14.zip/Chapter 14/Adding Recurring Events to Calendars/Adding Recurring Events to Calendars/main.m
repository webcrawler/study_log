//
//  main.m
//  Adding Recurring Events to Calendars
//
//  Created by Vandad Nahavandipoor on 24/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Adding_Recurring_Events_to_CalendarsAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Adding_Recurring_Events_to_CalendarsAppDelegate class]));
  }
}
