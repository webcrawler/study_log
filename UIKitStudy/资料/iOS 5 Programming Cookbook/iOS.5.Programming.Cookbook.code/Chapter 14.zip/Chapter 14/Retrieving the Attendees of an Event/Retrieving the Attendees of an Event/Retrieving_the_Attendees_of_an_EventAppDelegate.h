//
//  Retrieving_the_Attendees_of_an_EventAppDelegate.h
//  Retrieving the Attendees of an Event
//
//  Created by Vandad Nahavandipoor on 24/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <EventKit/EventKit.h>

@interface Retrieving_the_Attendees_of_an_EventAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
