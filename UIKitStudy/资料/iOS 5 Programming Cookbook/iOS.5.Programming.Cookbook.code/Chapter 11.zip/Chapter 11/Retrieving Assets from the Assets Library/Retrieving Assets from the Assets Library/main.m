//
//  main.m
//  Retrieving Assets from the Assets Library
//
//  Created by Vandad Nahavandipoor on 22/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Retrieving_Assets_from_the_Assets_LibraryAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Retrieving_Assets_from_the_Assets_LibraryAppDelegate class]));
  }
}
