//
//  Retrieving_Assets_from_the_Assets_LibraryAppDelegate.h
//  Retrieving Assets from the Assets Library
//
//  Created by Vandad Nahavandipoor on 22/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Retrieving_Assets_from_the_Assets_LibraryViewController;

@interface Retrieving_Assets_from_the_Assets_LibraryAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Retrieving_Assets_from_the_Assets_LibraryViewController *viewController;

@end
