//
//  main.m
//  Detecting and Probing the Camera
//
//  Created by Vandad Nahavandipoor on 22/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Detecting_and_Probing_the_CameraAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Detecting_and_Probing_the_CameraAppDelegate class]));
  }
}
