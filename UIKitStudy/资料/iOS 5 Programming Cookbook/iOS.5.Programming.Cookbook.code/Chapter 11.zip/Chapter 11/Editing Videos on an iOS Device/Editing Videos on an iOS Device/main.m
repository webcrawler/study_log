//
//  main.m
//  Editing Videos on an iOS Device
//
//  Created by Vandad Nahavandipoor on 22/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Editing_Videos_on_an_iOS_DeviceAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Editing_Videos_on_an_iOS_DeviceAppDelegate class]));
  }
}
