//
//  main.m
//  Retrieving Photos and Videos from the Photo Library
//
//  Created by Vandad Nahavandipoor on 22/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Retrieving_Photos_and_Videos_from_the_Photo_LibraryAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Retrieving_Photos_and_Videos_from_the_Photo_LibraryAppDelegate class]));
  }
}
