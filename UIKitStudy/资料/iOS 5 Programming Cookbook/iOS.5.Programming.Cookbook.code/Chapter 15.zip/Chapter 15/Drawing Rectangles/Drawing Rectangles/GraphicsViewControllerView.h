//
//  GraphicsViewControllerView.h
//  Drawing Rectangles
//
//  Created by Vandad Nahavandipoor on 17/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GraphicsViewControllerView : UIView

@end
