//
//  Constructing__Setting__and_Using_ColorsAppDelegate.h
//  Constructing, Setting, and Using Colors
//
//  Created by Vandad Nahavandipoor on 17/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Constructing__Setting__and_Using_ColorsViewController;

@interface Constructing__Setting__and_Using_ColorsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Constructing__Setting__and_Using_ColorsViewController *viewController;

@end
