//
//  Animating_and_Moving_ViewsViewController.h
//  Animating and Moving Views
//
//  Created by Vandad Nahavandipoor on 17/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

/* 1 */
//#import <UIKit/UIKit.h>
//
//@interface Animating_and_Moving_ViewsViewController : UIViewController
//
//@property (nonatomic, strong) UIImageView *xcodeImageView;
//
//@end

/* 2 */
#import <UIKit/UIKit.h>

@interface Animating_and_Moving_ViewsViewController : UIViewController

@property (nonatomic, strong) UIImageView *xcodeImageView1;
@property (nonatomic, strong) UIImageView *xcodeImageView2;

@end