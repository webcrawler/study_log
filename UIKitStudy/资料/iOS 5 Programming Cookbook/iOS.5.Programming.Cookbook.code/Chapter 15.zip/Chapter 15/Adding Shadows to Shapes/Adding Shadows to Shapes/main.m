//
//  main.m
//  Adding Shadows to Shapes
//
//  Created by Vandad Nahavandipoor on 17/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Adding_Shadows_to_ShapesAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Adding_Shadows_to_ShapesAppDelegate class]));
  }
}
