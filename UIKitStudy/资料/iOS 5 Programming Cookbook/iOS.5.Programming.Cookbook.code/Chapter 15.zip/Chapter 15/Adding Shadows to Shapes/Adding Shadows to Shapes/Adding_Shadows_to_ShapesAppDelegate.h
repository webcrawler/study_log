//
//  Adding_Shadows_to_ShapesAppDelegate.h
//  Adding Shadows to Shapes
//
//  Created by Vandad Nahavandipoor on 17/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Adding_Shadows_to_ShapesViewController;

@interface Adding_Shadows_to_ShapesAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Adding_Shadows_to_ShapesViewController *viewController;

@end
