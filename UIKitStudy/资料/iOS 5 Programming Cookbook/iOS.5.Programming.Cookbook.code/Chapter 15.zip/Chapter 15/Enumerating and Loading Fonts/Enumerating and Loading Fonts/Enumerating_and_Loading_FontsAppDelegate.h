//
//  Enumerating_and_Loading_FontsAppDelegate.h
//  Enumerating and Loading Fonts
//
//  Created by Vandad Nahavandipoor on 17/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Enumerating_and_Loading_FontsViewController;

@interface Enumerating_and_Loading_FontsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Enumerating_and_Loading_FontsViewController *viewController;

@end
