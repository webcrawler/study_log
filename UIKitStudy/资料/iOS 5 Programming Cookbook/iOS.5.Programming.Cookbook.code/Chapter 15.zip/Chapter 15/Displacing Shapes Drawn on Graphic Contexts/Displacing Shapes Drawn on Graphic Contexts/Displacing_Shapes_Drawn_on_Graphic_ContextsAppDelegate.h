//
//  Displacing_Shapes_Drawn_on_Graphic_ContextsAppDelegate.h
//  Displacing Shapes Drawn on Graphic Contexts
//
//  Created by Vandad Nahavandipoor on 17/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Displacing_Shapes_Drawn_on_Graphic_ContextsViewController;

@interface Displacing_Shapes_Drawn_on_Graphic_ContextsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Displacing_Shapes_Drawn_on_Graphic_ContextsViewController *viewController;

@end
