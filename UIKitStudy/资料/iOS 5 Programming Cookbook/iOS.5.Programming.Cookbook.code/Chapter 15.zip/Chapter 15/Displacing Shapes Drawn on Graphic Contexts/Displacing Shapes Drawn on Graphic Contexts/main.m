//
//  main.m
//  Displacing Shapes Drawn on Graphic Contexts
//
//  Created by Vandad Nahavandipoor on 17/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Displacing_Shapes_Drawn_on_Graphic_ContextsAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Displacing_Shapes_Drawn_on_Graphic_ContextsAppDelegate class]));
  }
}
