//
//  Animating_and_Rotating_ViewsViewController.h
//  Animating and Rotating Views
//
//  Created by Vandad Nahavandipoor on 17/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Animating_and_Rotating_ViewsViewController : UIViewController

@property (nonatomic, strong) UIImageView *xcodeImageView;

@end
