//
//  Constructing_PathsAppDelegate.h
//  Constructing Paths
//
//  Created by Vandad Nahavandipoor on 17/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Constructing_PathsViewController;

@interface Constructing_PathsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Constructing_PathsViewController *viewController;

@end
