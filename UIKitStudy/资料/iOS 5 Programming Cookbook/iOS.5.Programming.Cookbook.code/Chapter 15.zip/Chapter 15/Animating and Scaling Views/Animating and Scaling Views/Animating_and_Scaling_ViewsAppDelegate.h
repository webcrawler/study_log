//
//  Animating_and_Scaling_ViewsAppDelegate.h
//  Animating and Scaling Views
//
//  Created by Vandad Nahavandipoor on 17/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Animating_and_Scaling_ViewsViewController;

@interface Animating_and_Scaling_ViewsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Animating_and_Scaling_ViewsViewController *viewController;

@end
