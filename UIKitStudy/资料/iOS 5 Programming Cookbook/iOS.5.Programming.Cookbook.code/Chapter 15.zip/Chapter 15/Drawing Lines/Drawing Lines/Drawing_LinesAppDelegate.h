//
//  Drawing_LinesAppDelegate.h
//  Drawing Lines
//
//  Created by Vandad Nahavandipoor on 17/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Drawing_LinesViewController;

@interface Drawing_LinesAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Drawing_LinesViewController *viewController;

@end
