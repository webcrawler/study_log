//
//  MySingleton.h
//  Performing a Task at Most Once with GCD
//
//  Created by Vandad Nahavandipoor on 13/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MySingleton : NSObject

@end
