//
//  Performing_a_Task_at_Most_Once_with_GCDAppDelegate.h
//  Performing a Task at Most Once with GCD
//
//  Created by Vandad Nahavandipoor on 13/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Performing_a_Task_at_Most_Once_with_GCDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
