//
//  Performing_UI_Related_Tasks_with_GCDAppDelegate.h
//  Performing UI-Related Tasks with GCD
//
//  Created by Vandad Nahavandipoor on 13/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Performing_UI_Related_Tasks_with_GCDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
