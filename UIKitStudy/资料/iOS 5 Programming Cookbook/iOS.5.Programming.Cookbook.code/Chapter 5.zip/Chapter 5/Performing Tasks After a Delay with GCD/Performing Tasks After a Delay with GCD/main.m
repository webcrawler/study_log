//
//  main.m
//  Performing Tasks After a Delay with GCD
//
//  Created by Vandad Nahavandipoor on 13/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Performing_Tasks_After_a_Delay_with_GCDAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Performing_Tasks_After_a_Delay_with_GCDAppDelegate class]));
  }
}
