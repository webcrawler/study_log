//
//  CountingOperation.h
//  Operations
//
//  Created by Vandad Nahavandipoor on 11-08-29.
//  Copyright 2011  All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SimpleOperation : NSOperation

/* Designated Initializer */
- (id) initWithObject:(NSObject *)paramObject;

@end