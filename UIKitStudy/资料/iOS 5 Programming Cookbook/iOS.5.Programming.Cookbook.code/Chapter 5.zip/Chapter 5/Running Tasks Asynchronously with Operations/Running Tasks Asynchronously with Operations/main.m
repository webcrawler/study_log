//
//  main.m
//  Running Tasks Asynchronously with Operations
//
//  Created by Vandad Nahavandipoor on 14/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Running_Tasks_Asynchronously_with_OperationsAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Running_Tasks_Asynchronously_with_OperationsAppDelegate class]));
  }
}
