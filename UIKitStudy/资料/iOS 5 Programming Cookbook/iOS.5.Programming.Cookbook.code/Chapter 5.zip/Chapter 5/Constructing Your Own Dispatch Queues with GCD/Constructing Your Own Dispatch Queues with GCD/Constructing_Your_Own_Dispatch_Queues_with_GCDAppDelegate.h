//
//  Constructing_Your_Own_Dispatch_Queues_with_GCDAppDelegate.h
//  Constructing Your Own Dispatch Queues with GCD
//
//  Created by Vandad Nahavandipoor on 14/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Constructing_Your_Own_Dispatch_Queues_with_GCDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
