//
//  main.m
//  Constructing Your Own Dispatch Queues with GCD
//
//  Created by Vandad Nahavandipoor on 14/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Constructing_Your_Own_Dispatch_Queues_with_GCDAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Constructing_Your_Own_Dispatch_Queues_with_GCDAppDelegate class]));
  }
}
