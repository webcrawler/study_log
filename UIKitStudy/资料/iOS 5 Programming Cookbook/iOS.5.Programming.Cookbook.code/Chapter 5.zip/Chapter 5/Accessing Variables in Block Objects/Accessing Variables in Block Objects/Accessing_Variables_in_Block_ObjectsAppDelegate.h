//
//  Accessing_Variables_in_Block_ObjectsAppDelegate.h
//  Accessing Variables in Block Objects
//
//  Created by Vandad Nahavandipoor on 13/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Accessing_Variables_in_Block_ObjectsAppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;
@property (nonatomic, strong) NSString *stringProperty;

@end
