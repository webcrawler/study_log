//
//  Grouping_Tasks_Together_with_GCDAppDelegate.h
//  Grouping Tasks Together with GCD
//
//  Created by Vandad Nahavandipoor on 14/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Grouping_Tasks_Together_with_GCDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
