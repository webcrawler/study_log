//
//  Adding_Buttons_to_the_User_Interface_with_UIButtonAppDelegate.h
//  Adding Buttons to the User Interface with UIButton
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Adding_Buttons_to_the_User_Interface_with_UIButtonViewController;

@interface Adding_Buttons_to_the_User_Interface_with_UIButtonAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Adding_Buttons_to_the_User_Interface_with_UIButtonViewController *viewController;

@end
