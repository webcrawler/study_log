//
//  Adding_Buttons_to_the_User_Interface_with_UIButtonViewController.h
//  Adding Buttons to the User Interface with UIButton
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Adding_Buttons_to_the_User_Interface_with_UIButtonViewController
           : UIViewController

@property (nonatomic, strong) UIButton *myButton;

@end
