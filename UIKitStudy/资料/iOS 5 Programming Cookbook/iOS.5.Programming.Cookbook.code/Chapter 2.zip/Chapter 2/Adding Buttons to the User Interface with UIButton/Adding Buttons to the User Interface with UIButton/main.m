//
//  main.m
//  Adding Buttons to the User Interface with UIButton
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Adding_Buttons_to_the_User_Interface_with_UIButtonAppDelegate.h"

int main(int argc, char *argv[])
{
  int retVal = 0;
  @autoreleasepool {
      retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([Adding_Buttons_to_the_User_Interface_with_UIButtonAppDelegate class]));
  }
  return retVal;
}
