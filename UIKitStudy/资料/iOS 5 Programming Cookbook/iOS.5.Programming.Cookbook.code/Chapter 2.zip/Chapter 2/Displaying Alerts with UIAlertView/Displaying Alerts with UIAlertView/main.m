//
//  main.m
//  Displaying Alerts with UIAlertView
//
//  Created by Vandad Nahavandipoor on 16/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Displaying_Alerts_with_UIAlertViewAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Displaying_Alerts_with_UIAlertViewAppDelegate class]));
  }
}
