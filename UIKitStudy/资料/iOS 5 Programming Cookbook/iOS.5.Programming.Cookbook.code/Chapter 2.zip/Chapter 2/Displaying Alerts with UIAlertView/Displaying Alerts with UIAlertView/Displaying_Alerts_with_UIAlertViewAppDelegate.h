//
//  Displaying_Alerts_with_UIAlertViewAppDelegate.h
//  Displaying Alerts with UIAlertView
//
//  Created by Vandad Nahavandipoor on 16/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Displaying_Alerts_with_UIAlertViewViewController;

@interface Displaying_Alerts_with_UIAlertViewAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Displaying_Alerts_with_UIAlertViewViewController *viewController;

@end
