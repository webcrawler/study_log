//
//  main.m
//  Picking Date and Time with UIDatePicker
//
//  Created by Vandad Nahavandipoor on 08/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Picking_Date_and_Time_with_UIDatePickerAppDelegate.h"

int main(int argc, char *argv[])
{
  int retVal = 0;
  @autoreleasepool {
      retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([Picking_Date_and_Time_with_UIDatePickerAppDelegate class]));
  }
  return retVal;
}
