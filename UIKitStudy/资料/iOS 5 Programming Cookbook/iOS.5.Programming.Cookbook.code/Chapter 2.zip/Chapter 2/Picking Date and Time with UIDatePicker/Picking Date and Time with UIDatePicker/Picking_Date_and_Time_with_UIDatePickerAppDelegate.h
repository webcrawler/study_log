//
//  Picking_Date_and_Time_with_UIDatePickerAppDelegate.h
//  Picking Date and Time with UIDatePicker
//
//  Created by Vandad Nahavandipoor on 08/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Picking_Date_and_Time_with_UIDatePickerViewController;

@interface Picking_Date_and_Time_with_UIDatePickerAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Picking_Date_and_Time_with_UIDatePickerViewController *viewController;

@end
