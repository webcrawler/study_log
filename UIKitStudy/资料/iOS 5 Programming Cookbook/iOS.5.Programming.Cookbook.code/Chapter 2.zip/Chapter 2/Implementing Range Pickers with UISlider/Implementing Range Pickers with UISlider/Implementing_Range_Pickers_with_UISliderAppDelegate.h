//
//  Implementing_Range_Pickers_with_UISliderAppDelegate.h
//  Implementing Range Pickers with UISlider
//
//  Created by Vandad Nahavandipoor on 08/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Implementing_Range_Pickers_with_UISliderViewController;

@interface Implementing_Range_Pickers_with_UISliderAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Implementing_Range_Pickers_with_UISliderViewController *viewController;

@end
