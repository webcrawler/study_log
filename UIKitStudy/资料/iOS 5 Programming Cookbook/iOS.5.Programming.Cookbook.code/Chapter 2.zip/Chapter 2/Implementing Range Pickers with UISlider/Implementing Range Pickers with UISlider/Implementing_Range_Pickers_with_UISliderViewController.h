//
//  Implementing_Range_Pickers_with_UISliderViewController.h
//  Implementing Range Pickers with UISlider
//
//  Created by Vandad Nahavandipoor on 08/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Implementing_Range_Pickers_with_UISliderViewController 
           : UIViewController

@property (nonatomic, strong) UISlider *mySlider;

@end
