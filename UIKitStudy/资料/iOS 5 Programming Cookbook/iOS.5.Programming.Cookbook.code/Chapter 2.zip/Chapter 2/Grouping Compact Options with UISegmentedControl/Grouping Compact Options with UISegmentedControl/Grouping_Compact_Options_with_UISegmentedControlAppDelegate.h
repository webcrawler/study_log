//
//  Grouping_Compact_Options_with_UISegmentedControlAppDelegate.h
//  Grouping Compact Options with UISegmentedControl
//
//  Created by Vandad Nahavandipoor on 09/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Grouping_Compact_Options_with_UISegmentedControlViewController;

@interface Grouping_Compact_Options_with_UISegmentedControlAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Grouping_Compact_Options_with_UISegmentedControlViewController *viewController;

@end
