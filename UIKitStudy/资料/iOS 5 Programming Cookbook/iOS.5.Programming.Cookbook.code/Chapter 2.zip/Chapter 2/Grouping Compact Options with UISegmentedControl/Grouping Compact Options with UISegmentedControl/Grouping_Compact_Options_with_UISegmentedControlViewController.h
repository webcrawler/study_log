//
//  Grouping_Compact_Options_with_UISegmentedControlViewController.h
//  Grouping Compact Options with UISegmentedControl
//
//  Created by Vandad Nahavandipoor on 09/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Grouping_Compact_Options_with_UISegmentedControlViewController
           : UIViewController

@property (nonatomic, strong) UISegmentedControl *mySegmentedControl;

@end
