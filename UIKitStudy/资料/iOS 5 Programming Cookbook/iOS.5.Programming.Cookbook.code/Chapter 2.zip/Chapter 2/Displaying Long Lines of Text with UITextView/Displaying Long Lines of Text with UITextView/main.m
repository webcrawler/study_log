//
//  main.m
//  Displaying Long Lines of Text with UITextView
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Displaying_Long_Lines_of_Text_with_UITextViewAppDelegate.h"

int main(int argc, char *argv[])
{
  int retVal = 0;
  @autoreleasepool {
      retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([Displaying_Long_Lines_of_Text_with_UITextViewAppDelegate class]));
  }
  return retVal;
}
