//
//  Displaying_Long_Lines_of_Text_with_UITextViewViewController.h
//  Displaying Long Lines of Text with UITextView
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Displaying_Long_Lines_of_Text_with_UITextViewViewController 
           : UIViewController

@property (nonatomic, strong) UITextView *myTextView;

@end
