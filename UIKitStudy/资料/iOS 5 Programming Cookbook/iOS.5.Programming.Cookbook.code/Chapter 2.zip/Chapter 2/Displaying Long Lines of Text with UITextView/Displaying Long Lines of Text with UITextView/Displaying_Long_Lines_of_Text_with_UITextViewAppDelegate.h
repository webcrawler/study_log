//
//  Displaying_Long_Lines_of_Text_with_UITextViewAppDelegate.h
//  Displaying Long Lines of Text with UITextView
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Displaying_Long_Lines_of_Text_with_UITextViewViewController;

@interface Displaying_Long_Lines_of_Text_with_UITextViewAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Displaying_Long_Lines_of_Text_with_UITextViewViewController *viewController;

@end
