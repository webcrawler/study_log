//
//  Accepting_User_Text_Input_with_UITextFieldAppDelegate.h
//  Accepting User Text Input with UITextField
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Accepting_User_Text_Input_with_UITextFieldViewController;

@interface Accepting_User_Text_Input_with_UITextFieldAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Accepting_User_Text_Input_with_UITextFieldViewController *viewController;

@end
