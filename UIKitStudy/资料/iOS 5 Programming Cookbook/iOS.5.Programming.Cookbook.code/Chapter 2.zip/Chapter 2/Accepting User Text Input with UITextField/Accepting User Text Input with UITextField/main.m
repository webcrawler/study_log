//
//  main.m
//  Accepting User Text Input with UITextField
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Accepting_User_Text_Input_with_UITextFieldAppDelegate.h"

int main(int argc, char *argv[])
{
  int retVal = 0;
  @autoreleasepool {
      retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([Accepting_User_Text_Input_with_UITextFieldAppDelegate class]));
  }
  return retVal;
}
