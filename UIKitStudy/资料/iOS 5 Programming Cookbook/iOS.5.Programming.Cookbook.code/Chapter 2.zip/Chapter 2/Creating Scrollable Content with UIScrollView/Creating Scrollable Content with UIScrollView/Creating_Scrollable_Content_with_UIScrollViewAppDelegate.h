//
//  Creating_Scrollable_Content_with_UIScrollViewAppDelegate.h
//  Creating Scrollable Content with UIScrollView
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Creating_Scrollable_Content_with_UIScrollViewViewController;

@interface Creating_Scrollable_Content_with_UIScrollViewAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Creating_Scrollable_Content_with_UIScrollViewViewController *viewController;

@end
