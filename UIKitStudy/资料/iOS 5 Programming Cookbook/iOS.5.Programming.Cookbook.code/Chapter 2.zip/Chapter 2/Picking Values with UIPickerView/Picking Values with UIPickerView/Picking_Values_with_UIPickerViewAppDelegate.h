//
//  Picking_Values_with_UIPickerViewAppDelegate.h
//  Picking Values with UIPickerView
//
//  Created by Vandad Nahavandipoor on 08/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Picking_Values_with_UIPickerViewViewController;

@interface Picking_Values_with_UIPickerViewAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Picking_Values_with_UIPickerViewViewController *viewController;

@end
