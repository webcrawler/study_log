//
//  main.m
//  Picking Values with UIPickerView
//
//  Created by Vandad Nahavandipoor on 08/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Picking_Values_with_UIPickerViewAppDelegate.h"

int main(int argc, char *argv[])
{
  int retVal = 0;
  @autoreleasepool {
      retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([Picking_Values_with_UIPickerViewAppDelegate class]));
  }
  return retVal;
}
