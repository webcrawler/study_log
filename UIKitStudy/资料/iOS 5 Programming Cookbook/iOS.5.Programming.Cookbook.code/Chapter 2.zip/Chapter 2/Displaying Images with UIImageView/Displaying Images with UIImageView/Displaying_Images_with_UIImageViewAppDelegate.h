//
//  Displaying_Images_with_UIImageViewAppDelegate.h
//  Displaying Images with UIImageView
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Displaying_Images_with_UIImageViewViewController;

@interface Displaying_Images_with_UIImageViewAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Displaying_Images_with_UIImageViewViewController *viewController;

@end
