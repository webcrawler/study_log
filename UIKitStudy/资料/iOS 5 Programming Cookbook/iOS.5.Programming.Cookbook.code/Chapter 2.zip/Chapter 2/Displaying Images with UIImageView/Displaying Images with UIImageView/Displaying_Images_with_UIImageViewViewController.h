//
//  Displaying_Images_with_UIImageViewViewController.h
//  Displaying Images with UIImageView
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Displaying_Images_with_UIImageViewViewController
           : UIViewController

@property (nonatomic, strong) UIImageView *myImageView;

@end
