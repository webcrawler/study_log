//
//  ViewController.h
//  Displaying Progress with UIProgressView
//
//  Created by Vandad Nahavandipoor on 30/08/2011.
//  Copyright (c) 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) UIProgressView *progressView;

@end
