//
//  Displaying_Static_Text_with_UILabelAppDelegate.h
//  Displaying Static Text with UILabel
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Displaying_Static_Text_with_UILabelViewController;

@interface Displaying_Static_Text_with_UILabelAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Displaying_Static_Text_with_UILabelViewController *viewController;

@end
