//
//  main.m
//  Displaying Static Text with UILabel
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Displaying_Static_Text_with_UILabelAppDelegate.h"

int main(int argc, char *argv[])
{
  int retVal = 0;
  @autoreleasepool {
      retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([Displaying_Static_Text_with_UILabelAppDelegate class]));
  }
  return retVal;
}
