//
//  Displaying_Static_Text_with_UILabelViewController.h
//  Displaying Static Text with UILabel
//
//  Created by Vandad Nahavandipoor on 10/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Displaying_Static_Text_with_UILabelViewController 
           : UIViewController

@property (nonatomic, strong) UILabel *myLabel;

@end
