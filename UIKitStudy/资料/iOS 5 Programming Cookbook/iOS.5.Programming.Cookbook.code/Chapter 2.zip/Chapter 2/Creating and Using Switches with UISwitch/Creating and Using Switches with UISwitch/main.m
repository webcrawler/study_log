//
//  main.m
//  Creating and Using Switches with UISwitch
//
//  Created by Vandad Nahavandipoor on 08/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Creating_and_Using_Switches_with_UISwitchAppDelegate.h"

int main(int argc, char *argv[])
{
  int retVal = 0;
  @autoreleasepool {
      retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([Creating_and_Using_Switches_with_UISwitchAppDelegate class]));
  }
  return retVal;
}
