//
//  Creating_and_Using_Switches_with_UISwitchAppDelegate.h
//  Creating and Using Switches with UISwitch
//
//  Created by Vandad Nahavandipoor on 08/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Creating_and_Using_Switches_with_UISwitchViewController;

@interface Creating_and_Using_Switches_with_UISwitchAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Creating_and_Using_Switches_with_UISwitchViewController *viewController;

@end
