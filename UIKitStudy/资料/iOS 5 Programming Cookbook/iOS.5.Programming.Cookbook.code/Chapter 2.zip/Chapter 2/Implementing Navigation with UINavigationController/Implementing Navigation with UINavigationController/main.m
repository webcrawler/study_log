//
//  main.m
//  Implementing Navigation with UINavigationController
//
//  Created by Vandad Nahavandipoor on 09/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Implementing_Navigation_with_UINavigationControllerAppDelegate.h"

int main(int argc, char *argv[])
{
  int retVal = 0;
  @autoreleasepool {
      retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([Implementing_Navigation_with_UINavigationControllerAppDelegate class]));
  }
  return retVal;
}
