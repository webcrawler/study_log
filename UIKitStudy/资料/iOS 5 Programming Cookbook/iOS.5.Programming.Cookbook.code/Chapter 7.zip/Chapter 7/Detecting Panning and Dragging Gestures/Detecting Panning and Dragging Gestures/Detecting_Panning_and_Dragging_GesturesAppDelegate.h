//
//  Detecting_Panning_and_Dragging_GesturesAppDelegate.h
//  Detecting Panning and Dragging Gestures
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Detecting_Panning_and_Dragging_GesturesViewController;

@interface Detecting_Panning_and_Dragging_GesturesAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Detecting_Panning_and_Dragging_GesturesViewController *viewController;

@end
