//
//  Detecting_Rotation_GesturesAppDelegate.h
//  Detecting Rotation Gestures
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Detecting_Rotation_GesturesViewController;

@interface Detecting_Rotation_GesturesAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Detecting_Rotation_GesturesViewController *viewController;

@end
