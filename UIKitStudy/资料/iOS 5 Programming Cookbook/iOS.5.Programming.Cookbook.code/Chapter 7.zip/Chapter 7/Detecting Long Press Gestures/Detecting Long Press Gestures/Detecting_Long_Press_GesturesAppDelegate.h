//
//  Detecting_Long_Press_GesturesAppDelegate.h
//  Detecting Long Press Gestures
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Detecting_Long_Press_GesturesViewController;

@interface Detecting_Long_Press_GesturesAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Detecting_Long_Press_GesturesViewController *viewController;

@end
