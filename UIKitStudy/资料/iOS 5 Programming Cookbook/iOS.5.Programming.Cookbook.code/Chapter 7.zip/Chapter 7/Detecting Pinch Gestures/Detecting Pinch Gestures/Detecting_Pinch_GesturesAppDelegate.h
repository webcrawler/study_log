//
//  Detecting_Pinch_GesturesAppDelegate.h
//  Detecting Pinch Gestures
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Detecting_Pinch_GesturesViewController;

@interface Detecting_Pinch_GesturesAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Detecting_Pinch_GesturesViewController *viewController;

@end
