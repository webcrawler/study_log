//
//  Detecting_Swipe_GesturesAppDelegate.h
//  Detecting Swipe Gestures
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Detecting_Swipe_GesturesViewController;

@interface Detecting_Swipe_GesturesAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Detecting_Swipe_GesturesViewController *viewController;

@end
