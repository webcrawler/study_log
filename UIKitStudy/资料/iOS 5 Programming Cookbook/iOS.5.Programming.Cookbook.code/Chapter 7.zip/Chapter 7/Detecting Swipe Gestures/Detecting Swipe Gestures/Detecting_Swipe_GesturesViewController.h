//
//  Detecting_Swipe_GesturesViewController.h
//  Detecting Swipe Gestures
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Detecting_Swipe_GesturesViewController : UIViewController

@property (nonatomic, strong)
  UISwipeGestureRecognizer *swipeGestureRecognizer;

@end
