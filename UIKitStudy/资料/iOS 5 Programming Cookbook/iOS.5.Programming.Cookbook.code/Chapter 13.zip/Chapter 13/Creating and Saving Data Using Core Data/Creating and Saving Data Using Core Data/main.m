//
//  main.m
//  Creating and Saving Data Using Core Data
//
//  Created by Vandad Nahavandipoor on 23/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Creating_and_Saving_Data_Using_Core_DataAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Creating_and_Saving_Data_Using_Core_DataAppDelegate class]));
  }
}
