//
//  Person.m
//  Creating and Saving Data Using Core Data
//
//  Created by Vandad Nahavandipoor on 23/07/2011.
//  Copyright (c) 2011 Pixolity Ltd. All rights reserved.
//

#import "Person.h"


@implementation Person
@dynamic firstName;
@dynamic lastName;
@dynamic age;

@end
