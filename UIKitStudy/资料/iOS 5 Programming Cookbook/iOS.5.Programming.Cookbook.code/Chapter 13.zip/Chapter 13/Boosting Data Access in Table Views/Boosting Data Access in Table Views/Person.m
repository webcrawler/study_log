//
//  Person.m
//  Boosting Data Access in Table Views
//
//  Created by Vandad Nahavandipoor on 23/07/2011.
//  Copyright (c) 2011 Pixolity Ltd. All rights reserved.
//

#import "Person.h"


@implementation Person
@dynamic firstName;
@dynamic lastName;
@dynamic age;

@end
