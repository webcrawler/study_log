//
//  Person.m
//  Generating Class Files for Core Data Entities
//
//  Created by Vandad Nahavandipoor on 23/07/2011.
//  Copyright (c) 2011 Pixolity Ltd. All rights reserved.
//

#import "Person.h"


@implementation Person
@dynamic firstName;
@dynamic lastName;
@dynamic age;

@end
