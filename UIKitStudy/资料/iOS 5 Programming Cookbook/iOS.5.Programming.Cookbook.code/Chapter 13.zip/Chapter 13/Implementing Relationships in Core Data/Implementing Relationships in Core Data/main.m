//
//  main.m
//  Implementing Relationships in Core Data
//
//  Created by Vandad Nahavandipoor on 23/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Implementing_Relationships_in_Core_DataAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Implementing_Relationships_in_Core_DataAppDelegate class]));
  }
}
