//
//  main.m
//  Creating a Core Data Model with Xcode
//
//  Created by Vandad Nahavandipoor on 23/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Creating_a_Core_Data_Model_with_XcodeAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Creating_a_Core_Data_Model_with_XcodeAppDelegate class]));
  }
}
