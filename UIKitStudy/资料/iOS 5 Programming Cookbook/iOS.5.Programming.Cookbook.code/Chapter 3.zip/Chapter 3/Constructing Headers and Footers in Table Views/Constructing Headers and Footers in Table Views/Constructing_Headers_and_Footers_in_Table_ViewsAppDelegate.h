//
//  Constructing_Headers_and_Footers_in_Table_ViewsAppDelegate.h
//  Constructing Headers and Footers in Table Views
//
//  Created by Vandad Nahavandipoor on 30/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Constructing_Headers_and_Footers_in_Table_ViewsViewController;

@interface Constructing_Headers_and_Footers_in_Table_ViewsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Constructing_Headers_and_Footers_in_Table_ViewsViewController *viewController;

@end
