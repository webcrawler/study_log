//
//  Displaying_Hierarchical_Data_in_Table_ViewsAppDelegate.h
//  Displaying Hierarchical Data in Table Views
//
//  Created by Vandad Nahavandipoor on 29/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Displaying_Hierarchical_Data_in_Table_ViewsViewController;

@interface Displaying_Hierarchical_Data_in_Table_ViewsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Displaying_Hierarchical_Data_in_Table_ViewsViewController *viewController;

@end
