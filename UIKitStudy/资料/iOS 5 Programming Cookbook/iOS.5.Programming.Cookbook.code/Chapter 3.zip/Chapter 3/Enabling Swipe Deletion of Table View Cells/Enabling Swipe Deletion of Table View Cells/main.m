//
//  main.m
//  Enabling Swipe Deletion of Table View Cells
//
//  Created by Vandad Nahavandipoor on 29/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Enabling_Swipe_Deletion_of_Table_View_CellsAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Enabling_Swipe_Deletion_of_Table_View_CellsAppDelegate class]));
  }
}
