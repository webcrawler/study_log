//
//  Instantiating_a_Table_ViewViewController.h
//  Instantiating a Table View
//
//  Created by Vandad Nahavandipoor on 11/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Instantiating_a_Table_ViewViewController : UIViewController

@property (nonatomic, strong) UITableView *myTableView;

@end
