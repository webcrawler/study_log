//
//  Instantiating_a_Table_ViewAppDelegate.h
//  Instantiating a Table View
//
//  Created by Vandad Nahavandipoor on 11/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Instantiating_a_Table_ViewViewController;

@interface Instantiating_a_Table_ViewAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Instantiating_a_Table_ViewViewController *viewController;

@end
