//
//  Receiving_and_Handling_Table_View_EventsAppDelegate.h
//  Receiving and Handling Table View Events
//
//  Created by Vandad Nahavandipoor on 29/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Receiving_and_Handling_Table_View_EventsViewController;

@interface Receiving_and_Handling_Table_View_EventsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Receiving_and_Handling_Table_View_EventsViewController *viewController;

@end
