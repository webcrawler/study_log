//
//  main.m
//  Receiving and Handling Table View Events
//
//  Created by Vandad Nahavandipoor on 29/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Receiving_and_Handling_Table_View_EventsAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Receiving_and_Handling_Table_View_EventsAppDelegate class]));
  }
}
