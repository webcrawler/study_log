//
//  main.m
//  Assigning a Delegate to a Table View
//
//  Created by Vandad Nahavandipoor on 11/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Assigning_a_Delegate_to_a_Table_ViewAppDelegate.h"

int main(int argc, char *argv[])
{
  int retVal = 0;
  @autoreleasepool {
      retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([Assigning_a_Delegate_to_a_Table_ViewAppDelegate class]));
  }
  return retVal;
}
