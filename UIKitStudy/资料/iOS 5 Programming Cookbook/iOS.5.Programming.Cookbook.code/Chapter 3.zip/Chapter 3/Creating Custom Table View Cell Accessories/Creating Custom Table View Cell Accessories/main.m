//
//  main.m
//  Creating Custom Table View Cell Accessories
//
//  Created by Vandad Nahavandipoor on 29/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Creating_Custom_Table_View_Cell_AccessoriesAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Creating_Custom_Table_View_Cell_AccessoriesAppDelegate class]));
  }
}
