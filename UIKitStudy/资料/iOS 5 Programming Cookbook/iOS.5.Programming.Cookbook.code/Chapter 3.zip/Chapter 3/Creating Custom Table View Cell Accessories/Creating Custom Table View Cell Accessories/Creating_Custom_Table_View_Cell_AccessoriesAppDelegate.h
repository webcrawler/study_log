//
//  Creating_Custom_Table_View_Cell_AccessoriesAppDelegate.h
//  Creating Custom Table View Cell Accessories
//
//  Created by Vandad Nahavandipoor on 29/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Creating_Custom_Table_View_Cell_AccessoriesViewController;

@interface Creating_Custom_Table_View_Cell_AccessoriesAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Creating_Custom_Table_View_Cell_AccessoriesViewController *viewController;

@end
