//
//  Moving_Cells_and_Sections_in_Table_ViewsAppDelegate.h
//  Moving Cells and Sections in Table Views
//
//  Created by Vandad Nahavandipoor on 07/08/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Moving_Cells_and_Sections_in_Table_ViewsViewController;

@interface Moving_Cells_and_Sections_in_Table_ViewsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Moving_Cells_and_Sections_in_Table_ViewsViewController *viewController;

@end
