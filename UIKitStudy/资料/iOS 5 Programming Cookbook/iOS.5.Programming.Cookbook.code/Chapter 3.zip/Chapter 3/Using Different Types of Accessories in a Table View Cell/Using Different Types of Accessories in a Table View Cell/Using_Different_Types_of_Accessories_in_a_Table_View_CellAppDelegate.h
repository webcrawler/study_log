//
//  Using_Different_Types_of_Accessories_in_a_Table_View_CellAppDelegate.h
//  Using Different Types of Accessories in a Table View Cell
//
//  Created by Vandad Nahavandipoor on 29/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Using_Different_Types_of_Accessories_in_a_Table_View_CellViewController;

@interface Using_Different_Types_of_Accessories_in_a_Table_View_CellAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Using_Different_Types_of_Accessories_in_a_Table_View_CellViewController *viewController;

@end
