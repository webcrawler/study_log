//
//  main.m
//  Integrating Twitter Functionality Into Your Apps
//
//  Created by Vandad Nahavandipoor on 20/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Integrating_Twitter_Functionality_Into_Your_AppsAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Integrating_Twitter_Functionality_Into_Your_AppsAppDelegate class]));
  }
}
