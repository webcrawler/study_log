//
//  main.m
//  Downloading Synchronously with NSURLConnection
//
//  Created by Vandad Nahavandipoor on 19/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Downloading_Synchronously_with_NSURLConnectionAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Downloading_Synchronously_with_NSURLConnectionAppDelegate class]));
  }
}
