//
//  main.m
//  Deserializing JSON into Arrays and Dictionaries
//
//  Created by Vandad Nahavandipoor on 20/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Deserializing_JSON_into_Arrays_and_DictionariesAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Deserializing_JSON_into_Arrays_and_DictionariesAppDelegate class]));
  }
}
