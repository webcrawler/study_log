//
//  Deserializing_JSON_into_Arrays_and_DictionariesAppDelegate.h
//  Deserializing JSON into Arrays and Dictionaries
//
//  Created by Vandad Nahavandipoor on 20/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Deserializing_JSON_into_Arrays_and_DictionariesAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
