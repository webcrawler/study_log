//
//  Serializing_Arrays_and_Dictionaries_into_JSONAppDelegate.h
//  Serializing Arrays and Dictionaries into JSON
//
//  Created by Vandad Nahavandipoor on 20/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Serializing_Arrays_and_Dictionaries_into_JSONAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
