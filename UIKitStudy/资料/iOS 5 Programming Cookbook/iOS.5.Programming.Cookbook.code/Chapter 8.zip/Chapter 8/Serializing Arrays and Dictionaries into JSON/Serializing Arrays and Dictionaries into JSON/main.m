//
//  main.m
//  Serializing Arrays and Dictionaries into JSON
//
//  Created by Vandad Nahavandipoor on 20/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Serializing_Arrays_and_Dictionaries_into_JSONAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Serializing_Arrays_and_Dictionaries_into_JSONAppDelegate class]));
  }
}
