//
//  main.m
//  Modifying a URL Request with NSMutableURLRequest
//
//  Created by Vandad Nahavandipoor on 19/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Modifying_a_URL_Request_with_NSMutableURLRequestAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Modifying_a_URL_Request_with_NSMutableURLRequestAppDelegate class]));
  }
}
