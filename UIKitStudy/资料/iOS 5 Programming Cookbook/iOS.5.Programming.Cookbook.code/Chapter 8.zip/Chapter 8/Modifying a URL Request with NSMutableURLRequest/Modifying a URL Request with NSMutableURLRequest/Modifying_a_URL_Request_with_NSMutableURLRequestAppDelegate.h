//
//  Modifying_a_URL_Request_with_NSMutableURLRequestAppDelegate.h
//  Modifying a URL Request with NSMutableURLRequest
//
//  Created by Vandad Nahavandipoor on 19/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Modifying_a_URL_Request_with_NSMutableURLRequestAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
