//
//  Handling_Timeouts_in_Asynchronous_ConnectionsAppDelegate.h
//  Handling Timeouts in Asynchronous Connections
//
//  Created by Vandad Nahavandipoor on 19/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Handling_Timeouts_in_Asynchronous_ConnectionsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
