//
//  main.m
//  Handling Timeouts in Asynchronous Connections
//
//  Created by Vandad Nahavandipoor on 19/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Handling_Timeouts_in_Asynchronous_ConnectionsAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Handling_Timeouts_in_Asynchronous_ConnectionsAppDelegate class]));
  }
}
