//
//  Sending_HTTP_DELETE_Requests_with_NSURLConnectionAppDelegate.h
//  Sending HTTP DELETE Requests with NSURLConnection
//
//  Created by Vandad Nahavandipoor on 19/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Sending_HTTP_DELETE_Requests_with_NSURLConnectionAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
