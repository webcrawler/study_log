//
//  main.m
//  Sending HTTP DELETE Requests with NSURLConnection
//
//  Created by Vandad Nahavandipoor on 19/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Sending_HTTP_DELETE_Requests_with_NSURLConnectionAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Sending_HTTP_DELETE_Requests_with_NSURLConnectionAppDelegate class]));
  }
}
