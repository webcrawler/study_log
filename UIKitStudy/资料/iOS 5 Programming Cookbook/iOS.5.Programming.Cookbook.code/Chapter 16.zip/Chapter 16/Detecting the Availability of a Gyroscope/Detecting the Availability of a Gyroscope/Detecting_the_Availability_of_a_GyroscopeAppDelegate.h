//
//  Detecting_the_Availability_of_a_GyroscopeAppDelegate.h
//  Detecting the Availability of a Gyroscope
//
//  Created by Vandad Nahavandipoor on 22/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>

@interface Detecting_the_Availability_of_a_GyroscopeAppDelegate
           : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end
