//
//  main.m
//  Detecting the Availability of a Gyroscope
//
//  Created by Vandad Nahavandipoor on 22/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Detecting_the_Availability_of_a_GyroscopeAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Detecting_the_Availability_of_a_GyroscopeAppDelegate class]));
  }
}
