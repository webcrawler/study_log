//
//  Detecting_Shakes_on_an_iOS_DeviceViewController.h
//  Detecting Shakes on an iOS Device
//
//  Created by Vandad Nahavandipoor on 22/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Detecting_Shakes_on_an_iOS_DeviceViewController : UIViewController

@end
