//
//  Detecting_Shakes_on_an_iOS_DeviceAppDelegate.h
//  Detecting Shakes on an iOS Device
//
//  Created by Vandad Nahavandipoor on 22/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Detecting_Shakes_on_an_iOS_DeviceViewController;

@interface Detecting_Shakes_on_an_iOS_DeviceAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Detecting_Shakes_on_an_iOS_DeviceViewController *viewController;

@end
