//
//  main.m
//  Retrieving Gyroscope Data
//
//  Created by Vandad Nahavandipoor on 22/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Retrieving_Gyroscope_DataAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Retrieving_Gyroscope_DataAppDelegate class]));
  }
}
