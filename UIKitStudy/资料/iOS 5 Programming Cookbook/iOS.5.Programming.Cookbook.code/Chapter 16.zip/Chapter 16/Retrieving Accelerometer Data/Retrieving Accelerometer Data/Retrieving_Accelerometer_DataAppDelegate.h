//
//  Retrieving_Accelerometer_DataAppDelegate.h
//  Retrieving Accelerometer Data
//
//  Created by Vandad Nahavandipoor on 22/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Retrieving_Accelerometer_DataViewController;

@interface Retrieving_Accelerometer_DataAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Retrieving_Accelerometer_DataViewController *viewController;

@end
