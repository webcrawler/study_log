//
//  ViewController.h
//  Searching for Files and Folders in iCloud
//
//  Created by Vandad Nahavandipoor on 17/09/2011.
//  Copyright (c) 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (nonatomic, strong) NSMetadataQuery *metadataQuery;

@end
