//
//  main.m
//  Converting Longitude and Latitude to a Meaningful Address
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Converting_Longitude_and_Latitude_to_a_Meaningful_AddressAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Converting_Longitude_and_Latitude_to_a_Meaningful_AddressAppDelegate class]));
  }
}
