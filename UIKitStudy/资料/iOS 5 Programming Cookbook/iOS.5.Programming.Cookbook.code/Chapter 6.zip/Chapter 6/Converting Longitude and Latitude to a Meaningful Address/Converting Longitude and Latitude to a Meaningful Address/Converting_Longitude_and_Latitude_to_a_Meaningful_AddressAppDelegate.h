//
//  Converting_Longitude_and_Latitude_to_a_Meaningful_AddressAppDelegate.h
//  Converting Longitude and Latitude to a Meaningful Address
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Converting_Longitude_and_Latitude_to_a_Meaningful_AddressViewController;

@interface Converting_Longitude_and_Latitude_to_a_Meaningful_AddressAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Converting_Longitude_and_Latitude_to_a_Meaningful_AddressViewController *viewController;

@end
