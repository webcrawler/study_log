//
//  Pinpointing_the_Location_of_a_DeviceAppDelegate.h
//  Pinpointing the Location of a Device
//
//  Created by Vandad Nahavandipoor on 14/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Pinpointing_the_Location_of_a_DeviceViewController;

@interface Pinpointing_the_Location_of_a_DeviceAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Pinpointing_the_Location_of_a_DeviceViewController *viewController;

@end
