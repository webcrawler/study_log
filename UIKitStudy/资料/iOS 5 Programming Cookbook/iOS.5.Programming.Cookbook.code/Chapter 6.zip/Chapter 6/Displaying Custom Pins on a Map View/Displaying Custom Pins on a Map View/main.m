//
//  main.m
//  Displaying Custom Pins on a Map View
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Displaying_Custom_Pins_on_a_Map_ViewAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Displaying_Custom_Pins_on_a_Map_ViewAppDelegate class]));
  }
}
