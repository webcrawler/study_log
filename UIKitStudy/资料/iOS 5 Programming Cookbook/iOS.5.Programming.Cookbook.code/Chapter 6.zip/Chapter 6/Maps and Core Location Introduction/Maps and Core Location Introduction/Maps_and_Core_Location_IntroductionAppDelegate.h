//
//  Maps_and_Core_Location_IntroductionAppDelegate.h
//  Maps and Core Location Introduction
//
//  Created by Vandad Nahavandipoor on 14/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Maps_and_Core_Location_IntroductionAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
