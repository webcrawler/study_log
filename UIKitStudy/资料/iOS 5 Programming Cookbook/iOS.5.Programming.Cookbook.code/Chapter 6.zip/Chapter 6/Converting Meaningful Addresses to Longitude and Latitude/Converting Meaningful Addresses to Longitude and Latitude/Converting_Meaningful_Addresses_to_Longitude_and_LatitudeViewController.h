//
//  Converting_Meaningful_Addresses_to_Longitude_and_LatitudeViewController.h
//  Converting Meaningful Addresses to Longitude and Latitude
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface
  Converting_Meaningful_Addresses_to_Longitude_and_LatitudeViewController
  : UIViewController

@property (nonatomic, strong) CLGeocoder *myGeocoder;

@end
