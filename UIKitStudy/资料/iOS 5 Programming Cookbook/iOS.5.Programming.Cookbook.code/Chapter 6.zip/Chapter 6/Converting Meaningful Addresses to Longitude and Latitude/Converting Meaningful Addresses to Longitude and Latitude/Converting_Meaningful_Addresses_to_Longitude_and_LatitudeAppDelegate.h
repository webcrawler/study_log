//
//  Converting_Meaningful_Addresses_to_Longitude_and_LatitudeAppDelegate.h
//  Converting Meaningful Addresses to Longitude and Latitude
//
//  Created by Vandad Nahavandipoor on 15/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Converting_Meaningful_Addresses_to_Longitude_and_LatitudeViewController;

@interface Converting_Meaningful_Addresses_to_Longitude_and_LatitudeAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Converting_Meaningful_Addresses_to_Longitude_and_LatitudeViewController *viewController;

@end
