//
//  Retrieving_and_Setting_a_Person_s_Address_Book_ImageAppDelegate.h
//  Retrieving and Setting a Person’s Address Book Image
//
//  Created by Vandad Nahavandipoor on 21/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Retrieving_and_Setting_a_Person_s_Address_Book_ImageViewController;

@interface Retrieving_and_Setting_a_Person_s_Address_Book_ImageAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Retrieving_and_Setting_a_Person_s_Address_Book_ImageViewController *viewController;

@end
