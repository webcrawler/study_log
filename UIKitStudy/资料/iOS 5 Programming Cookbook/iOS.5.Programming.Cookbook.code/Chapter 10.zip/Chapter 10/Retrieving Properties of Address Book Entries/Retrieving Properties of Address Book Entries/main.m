//
//  main.m
//  Retrieving Properties of Address Book Entries
//
//  Created by Vandad Nahavandipoor on 21/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Retrieving_Properties_of_Address_Book_EntriesAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Retrieving_Properties_of_Address_Book_EntriesAppDelegate class]));
  }
}
