//
//  Retrieving_All_the_People_in_the_Address_BookAppDelegate.h
//  Retrieving All the People in the Address Book
//
//  Created by Vandad Nahavandipoor on 21/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AddressBook/AddressBook.h>

@interface Retrieving_All_the_People_in_the_Address_BookAppDelegate
           : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end
