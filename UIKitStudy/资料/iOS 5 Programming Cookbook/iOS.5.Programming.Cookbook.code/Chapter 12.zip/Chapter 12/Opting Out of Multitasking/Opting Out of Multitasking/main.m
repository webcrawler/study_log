//
//  main.m
//  Opting Out of Multitasking
//
//  Created by Vandad Nahavandipoor on 21/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Opting_Out_of_MultitaskingAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Opting_Out_of_MultitaskingAppDelegate class]));
  }
}
