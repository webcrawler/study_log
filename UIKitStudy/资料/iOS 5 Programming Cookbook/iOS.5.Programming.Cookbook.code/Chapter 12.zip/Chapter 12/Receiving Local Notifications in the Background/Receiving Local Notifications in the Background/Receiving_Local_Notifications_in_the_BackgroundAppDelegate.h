//
//  Receiving_Local_Notifications_in_the_BackgroundAppDelegate.h
//  Receiving Local Notifications in the Background
//
//  Created by Vandad Nahavandipoor on 20/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Receiving_Local_Notifications_in_the_BackgroundAppDelegate
           : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end
