//
//  main.m
//  Receiving Local Notifications in the Background
//
//  Created by Vandad Nahavandipoor on 20/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Receiving_Local_Notifications_in_the_BackgroundAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Receiving_Local_Notifications_in_the_BackgroundAppDelegate class]));
  }
}
