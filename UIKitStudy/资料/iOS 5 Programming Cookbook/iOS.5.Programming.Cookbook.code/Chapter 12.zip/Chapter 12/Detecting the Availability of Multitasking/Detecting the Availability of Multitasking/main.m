//
//  main.m
//  Detecting the Availability of Multitasking
//
//  Created by Vandad Nahavandipoor on 20/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Detecting_the_Availability_of_MultitaskingAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Detecting_the_Availability_of_MultitaskingAppDelegate class]));
  }
}
