//
//  Detecting_the_Availability_of_MultitaskingAppDelegate.h
//  Detecting the Availability of Multitasking
//
//  Created by Vandad Nahavandipoor on 20/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Detecting_the_Availability_of_MultitaskingAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
