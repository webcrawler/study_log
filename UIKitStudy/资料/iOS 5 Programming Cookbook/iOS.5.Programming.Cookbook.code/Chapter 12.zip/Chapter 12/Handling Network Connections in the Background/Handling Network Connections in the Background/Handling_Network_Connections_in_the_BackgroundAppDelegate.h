//
//  Handling_Network_Connections_in_the_BackgroundAppDelegate.h
//  Handling Network Connections in the Background
//
//  Created by Vandad Nahavandipoor on 20/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Handling_Network_Connections_in_the_BackgroundAppDelegate
           : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
