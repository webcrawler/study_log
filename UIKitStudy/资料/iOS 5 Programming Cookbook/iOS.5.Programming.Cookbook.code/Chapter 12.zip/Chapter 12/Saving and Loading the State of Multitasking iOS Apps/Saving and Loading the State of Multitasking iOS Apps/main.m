//
//  main.m
//  Saving and Loading the State of Multitasking iOS Apps
//
//  Created by Vandad Nahavandipoor on 20/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Saving_and_Loading_the_State_of_Multitasking_iOS_AppsAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Saving_and_Loading_the_State_of_Multitasking_iOS_AppsAppDelegate class]));
  }
}
