//
//  main.m
//  Handling Notifications Delivered to a Waking App
//
//  Created by Vandad Nahavandipoor on 21/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Handling_Notifications_Delivered_to_a_Waking_AppAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Handling_Notifications_Delivered_to_a_Waking_AppAppDelegate class]));
  }
}
