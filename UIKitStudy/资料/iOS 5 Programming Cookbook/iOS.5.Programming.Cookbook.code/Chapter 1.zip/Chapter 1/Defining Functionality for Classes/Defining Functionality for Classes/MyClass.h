//
//  MyClass.h
//  Defining Functionality for Classes
//
//  Created by Vandad Nahavandipoor on 29/10/2011.
//  Copyright (c) 2011 Pixolity Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyClass : NSObject

+ (id) allocAndInit;

@end
