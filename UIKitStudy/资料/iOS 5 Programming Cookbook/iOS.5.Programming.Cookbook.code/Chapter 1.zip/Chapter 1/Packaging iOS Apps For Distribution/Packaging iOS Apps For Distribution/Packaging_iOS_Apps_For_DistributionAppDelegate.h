//
//  Packaging_iOS_Apps_For_DistributionAppDelegate.h
//  Packaging iOS Apps For Distribution
//
//  Created by Vandad Nahavandipoor on 08/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Packaging_iOS_Apps_For_DistributionAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
