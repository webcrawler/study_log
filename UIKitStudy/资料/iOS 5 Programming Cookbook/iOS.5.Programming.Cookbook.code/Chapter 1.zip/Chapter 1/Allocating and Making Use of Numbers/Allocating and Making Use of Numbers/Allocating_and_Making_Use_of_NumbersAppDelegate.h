//
//  Allocating_and_Making_Use_of_NumbersAppDelegate.h
//  Allocating and Making Use of Numbers
//
//  Created by Vandad Nahavandipoor on 06/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Allocating_and_Making_Use_of_NumbersAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
