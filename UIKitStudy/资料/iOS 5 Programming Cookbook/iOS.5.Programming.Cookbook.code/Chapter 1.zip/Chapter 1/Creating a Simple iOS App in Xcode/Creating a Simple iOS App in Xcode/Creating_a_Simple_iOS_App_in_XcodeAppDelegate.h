//
//  Creating_a_Simple_iOS_App_in_XcodeAppDelegate.h
//  Creating a Simple iOS App in Xcode
//
//  Created by Vandad Nahavandipoor on 07/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Creating_a_Simple_iOS_App_in_XcodeAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
