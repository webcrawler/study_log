//
//  Declaring_Variables_in_Objective_CAppDelegate.h
//  Declaring Variables in Objective-C
//
//  Created by Vandad Nahavandipoor on 08/08/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Declaring_Variables_in_Objective_CAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
