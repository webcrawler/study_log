//
//  main.m
//  Declaring Variables in Objective-C
//
//  Created by Vandad Nahavandipoor on 08/08/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Declaring_Variables_in_Objective_CAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Declaring_Variables_in_Objective_CAppDelegate class]));
  }
}
