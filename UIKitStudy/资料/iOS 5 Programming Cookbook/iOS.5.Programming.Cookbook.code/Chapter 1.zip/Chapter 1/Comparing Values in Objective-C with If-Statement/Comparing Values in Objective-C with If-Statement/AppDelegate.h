//
//  AppDelegate.h
//  Comparing Values in Objective-C with If-Statement
//
//  Created by Vandad Nahavandipoor on 23/08/2011.
//  Copyright (c) 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
