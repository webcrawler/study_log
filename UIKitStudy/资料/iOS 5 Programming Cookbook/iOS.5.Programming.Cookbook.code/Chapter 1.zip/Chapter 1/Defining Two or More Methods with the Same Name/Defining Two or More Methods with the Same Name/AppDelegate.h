//
//  AppDelegate.h
//  Defining Two or More Methods with the Same Name
//
//  Created by Vandad Nahavandipoor on 29/10/2011.
//  Copyright (c) 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
