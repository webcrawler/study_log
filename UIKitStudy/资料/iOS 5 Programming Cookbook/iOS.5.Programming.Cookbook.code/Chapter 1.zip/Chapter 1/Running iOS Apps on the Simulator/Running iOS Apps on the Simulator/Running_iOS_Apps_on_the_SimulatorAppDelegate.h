//
//  Running_iOS_Apps_on_the_SimulatorAppDelegate.h
//  Running iOS Apps on the Simulator
//
//  Created by Vandad Nahavandipoor on 08/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Running_iOS_Apps_on_the_SimulatorAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
