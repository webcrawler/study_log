//
//  main.m
//  Determining if Instance or Class Methods are Available
//
//  Created by Vandad Nahavandipoor on 08/08/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Determining_if_Instance_or_Class_Methods_are_AvailableAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Determining_if_Instance_or_Class_Methods_are_AvailableAppDelegate class]));
  }
}
