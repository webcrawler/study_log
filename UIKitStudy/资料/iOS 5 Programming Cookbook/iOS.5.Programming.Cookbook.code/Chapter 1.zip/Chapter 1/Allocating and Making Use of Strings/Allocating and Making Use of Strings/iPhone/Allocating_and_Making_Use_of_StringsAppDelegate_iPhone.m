//
//  Allocating_and_Making_Use_of_StringsAppDelegate_iPhone.m
//  Allocating and Making Use of Strings
//
//  Created by Vandad Nahavandipoor on 06/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import "Allocating_and_Making_Use_of_StringsAppDelegate_iPhone.h"

@implementation Allocating_and_Making_Use_of_StringsAppDelegate_iPhone

- (void)dealloc
{
	[super dealloc];
}

@end
