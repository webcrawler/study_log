//
//  Determining_if_a_Class_is_Available_at_Run_TimeAppDelegate.h
//  Determining if a Class is Available at Run Time
//
//  Created by Vandad Nahavandipoor on 08/08/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Determining_if_a_Class_is_Available_at_Run_TimeAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
