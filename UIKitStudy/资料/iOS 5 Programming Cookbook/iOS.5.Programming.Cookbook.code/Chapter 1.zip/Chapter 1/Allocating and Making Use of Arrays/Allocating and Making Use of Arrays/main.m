//
//  main.m
//  Allocating and Making Use of Arrays
//
//  Created by Vandad Nahavandipoor on 06/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Allocating_and_Making_Use_of_ArraysAppDelegate.h"

int main(int argc, char *argv[])
{
  int retVal = 0;
  @autoreleasepool {
      retVal = UIApplicationMain(argc, argv, nil, NSStringFromClass([Allocating_and_Making_Use_of_ArraysAppDelegate class]));
  }
  return retVal;
}
