//
//  Typecasting_with_Automatic_Reference_CountingAppDelegate.h
//  Typecasting with Automatic Reference Counting
//
//  Created by Vandad Nahavandipoor on 25/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Typecasting_with_Automatic_Reference_CountingAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
