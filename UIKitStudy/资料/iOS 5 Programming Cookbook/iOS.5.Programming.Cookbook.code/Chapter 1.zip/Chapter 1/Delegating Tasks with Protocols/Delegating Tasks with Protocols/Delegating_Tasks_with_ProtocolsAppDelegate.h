//
//  Delegating_Tasks_with_ProtocolsAppDelegate.h
//  Delegating Tasks with Protocols
//
//  Created by Vandad Nahavandipoor on 25/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PersonProtocol.h"

@interface Delegating_Tasks_with_ProtocolsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
