//
//  main.m
//  Delegating Tasks with Protocols
//
//  Created by Vandad Nahavandipoor on 25/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Delegating_Tasks_with_ProtocolsAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Delegating_Tasks_with_ProtocolsAppDelegate class]));
  }
}
