//
//  Father.m
//  Delegating Tasks with Protocols
//
//  Created by Vandad Nahavandipoor on 25/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import "Father.h"

@implementation Father

- (void) breathe{
  /* Implement this method here */
}

@end
