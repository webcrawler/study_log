//
//  Adding_a_Storyboard_to_an_Existing_ProjectAppDelegate.h
//  Adding a Storyboard to an Existing Project
//
//  Created by Vandad Nahavandipoor on 12/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Adding_a_Storyboard_to_an_Existing_ProjectViewController;

@interface Adding_a_Storyboard_to_an_Existing_ProjectAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Adding_a_Storyboard_to_an_Existing_ProjectViewController *viewController;

@end
