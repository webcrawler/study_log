//
//  Passing_Data_From_One_Screen_to_the_Other_AppDelegate.h
//  Passing Data From One Screen to the Other<
//
//  Created by Vandad Nahavandipoor on 12/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Passing_Data_From_One_Screen_to_the_Other_AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
