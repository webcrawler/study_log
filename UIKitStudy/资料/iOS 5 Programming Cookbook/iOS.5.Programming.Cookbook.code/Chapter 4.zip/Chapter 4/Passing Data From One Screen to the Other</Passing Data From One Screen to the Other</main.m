//
//  main.m
//  Passing Data From One Screen to the Other<
//
//  Created by Vandad Nahavandipoor on 12/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Passing_Data_From_One_Screen_to_the_Other_AppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([Passing_Data_From_One_Screen_to_the_Other_AppDelegate class]));
  }
}
