//
//  Creating_a_Project_with_StoryboardsAppDelegate.h
//  Creating a Project with Storyboards
//
//  Created by Vandad Nahavandipoor on 12/07/2011.
//  Copyright 2011 Pixolity Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Creating_a_Project_with_StoryboardsAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
